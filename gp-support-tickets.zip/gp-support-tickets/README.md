# GP Support Tickets

A self-hosted, no-third-party ticketing backend for Genesis Peptides.

## Important: architecture note

genesispeptides.com is a headless setup: the public storefront is a
separate Next.js application, and wp.genesispeptides.com (this WordPress
install) is used as a content/data backend. That means shortcode-rendered
WordPress pages, like the two shortcodes below, will only ever be reachable
at wp.genesispeptides.com directly. They will never appear on the actual
public site through normal navigation.

**The real integration path is the REST API** (see
`API-SPEC-FOR-FRONTEND.md`), which the Next.js frontend calls directly.
Send that file to whoever builds the frontend. The shortcode form is kept
in this plugin as a fallback: useful for testing the backend logic
directly, or as a stopgap support page reachable at
wp.genesispeptides.com/get-help/ if you need something working before the
frontend integration is built.

## Install

1. Upload `gp-support-tickets.zip` under Plugins > Add New > Upload Plugin
   on wp.genesispeptides.com (this is already done if you're reading this
   after the first round of testing).
2. Activate it.
3. WooCommerce is optional. If active and a ticket has an order number
   matching a real order, the admin ticket screen shows a read-only order
   snapshot (status, total, date, link to the order). This plugin never
   writes to WooCommerce or Kentro, only reads.

## Testing the backend directly (optional, works today)

Create a page on wp.genesispeptides.com with the shortcode
`[gp_ticket_form]`, and another with `[gp_ticket_status]`. View those pages
directly (Pages > All Pages > View), you don't need them in any menu. This
exercises the exact same backend logic the REST API uses, so it's a valid
way to confirm ticket creation, routing, and email notifications work
before the frontend integration exists.

## Testing the REST API directly

With the plugin active, these should respond without any frontend at all:

```
GET  https://wp.genesispeptides.com/wp-json/gp/v1/categories
POST https://wp.genesispeptides.com/wp-json/gp/v1/tickets
```

Use a tool like Postman, curl, or your browser's dev console for the GET
request. Full request/response shapes are in `API-SPEC-FOR-FRONTEND.md`.

## How the backend works

- A ticket is a custom post type (`gp_ticket`), shown in its own "Support
  Tickets" dashboard menu, separate from Posts and Pages.
- Category and priority are set automatically. Priority is never chosen by
  the customer: payment, order-status, and COA/lab-related categories start
  urgent, a keyword check (refund, damaged, chargeback, etc.) can bump
  others up, and any follow-up on an already-open ticket is always urgent.
- Replies use WordPress's native comment system as the thread, no separate
  messaging table. Staff reply from the normal comment box on the ticket's
  edit screen. Customer replies come through the REST API (or the fallback
  shortcode form).
- Every reply or status change sends a plain-text email notification
  automatically, both directions.
- The admin ticket list (Support Tickets) shows priority, status, category,
  order number, and customer, filterable by status.
- All ticket-creation, thread-reading, and reply logic lives in one place
  (`class-gpst-ticket-service.php`), used by both the REST API and the
  shortcode form, so the two paths can't drift out of sync.

## What's deliberately left out (for later)

- Knowledge base / FAQ (separate plugin, phase 2)
- COA lookup by lot number (phase 2)
- Frontend UI components (that's the dev team's side, see the API spec)

## Before moving to production

- Set the real frontend domain(s) in `allowed_origins()` in
  `includes/class-gpst-rest.php` (currently set to genesispeptides.com and
  www.genesispeptides.com — confirm these are correct and add any staging
  URLs the dev team needs during integration).
- Review the fixed category list in `includes/class-gpst-cpt.php` (top of
  the `GPST_CPT` class) and adjust wording if needed.
- Review the urgent-keyword list in `includes/class-gpst-routing.php` and
  tune it against real ticket language once you have a few weeks of data.
- Point the `gpst_admin_notification_email` filter at a real support inbox
  if you don't want notifications going to the site's main admin email.
