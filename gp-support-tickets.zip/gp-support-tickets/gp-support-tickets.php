<?php
/**
 * Plugin Name: GP Support Tickets
 * Plugin URI:  https://genesispeptides.com
 * Description: Self-hosted support ticket system for Genesis Peptides. Exposes a REST API (namespace gp/v1) for the headless Next.js storefront to call, plus a fallback on-site form via shortcode. Tickets are auto-prioritized and staff manage everything from a dedicated admin screen. No third-party service required.
 * Version:     0.1.0
 * Author:      Genesis Peptides
 * Text Domain: gp-support-tickets
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'GPST_VERSION', '0.1.0' );
define( 'GPST_PATH', plugin_dir_path( __FILE__ ) );
define( 'GPST_URL', plugin_dir_url( __FILE__ ) );

require_once GPST_PATH . 'includes/class-gpst-cpt.php';
require_once GPST_PATH . 'includes/class-gpst-routing.php';
require_once GPST_PATH . 'includes/class-gpst-notifications.php';
require_once GPST_PATH . 'includes/class-gpst-ticket-service.php';
require_once GPST_PATH . 'includes/class-gpst-frontend.php';
require_once GPST_PATH . 'includes/class-gpst-rest.php';
require_once GPST_PATH . 'includes/class-gpst-woocommerce.php';
require_once GPST_PATH . 'includes/class-gpst-admin-columns.php';

/**
 * Boot everything.
 */
function gpst_init() {
	GPST_CPT::instance();
	GPST_Routing::instance();
	GPST_Notifications::instance();
	GPST_Ticket_Service::instance();
	GPST_Frontend::instance();
	GPST_REST::instance();
	GPST_WooCommerce::instance();
	GPST_Admin_Columns::instance();
}
add_action( 'plugins_loaded', 'gpst_init' );

/**
 * Activation: register the post type immediately so rewrite rules flush correctly,
 * and create the default ticket categories.
 */
function gpst_activate() {
	require_once GPST_PATH . 'includes/class-gpst-cpt.php';
	GPST_CPT::instance()->register_post_type();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'gpst_activate' );

function gpst_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'gpst_deactivate' );

/**
 * Enqueue front-end assets only where needed (pages using the shortcodes).
 */
function gpst_enqueue_assets() {
	global $post;
	if ( is_a( $post, 'WP_Post' ) && ( has_shortcode( $post->post_content, 'gp_ticket_form' ) || has_shortcode( $post->post_content, 'gp_ticket_status' ) ) ) {
		wp_enqueue_style( 'gpst-frontend', GPST_URL . 'assets/css/gpst.css', array(), GPST_VERSION );
	}
}
add_action( 'wp_enqueue_scripts', 'gpst_enqueue_assets' );
