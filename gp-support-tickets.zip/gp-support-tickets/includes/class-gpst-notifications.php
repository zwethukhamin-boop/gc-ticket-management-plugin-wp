<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All outbound email lives here. Keep it plain-text and short:
 * these are transactional notices, not marketing.
 */
class GPST_Notifications {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Native WP comments are used as the reply thread. When a logged-in
		// staff member posts a comment on a ticket, notify the customer.
		add_action( 'wp_insert_comment', array( $this, 'maybe_notify_on_reply' ), 10, 2 );
	}

	private function admin_email() {
		return apply_filters( 'gpst_admin_notification_email', get_option( 'admin_email' ) );
	}

	/** New ticket submitted -> notify staff. */
	public function notify_admin_new_ticket( $post_id ) {
		$category = get_post_meta( $post_id, '_gpst_category', true );
		$priority = get_post_meta( $post_id, '_gpst_priority', true );
		$order    = get_post_meta( $post_id, '_gpst_order_number', true );
		$name     = get_post_meta( $post_id, '_gpst_customer_name', true );
		$email    = get_post_meta( $post_id, '_gpst_customer_email', true );

		$categories = GPST_CPT::categories();
		$cat_label  = isset( $categories[ $category ] ) ? $categories[ $category ] : $category;

		$subject = sprintf(
			'[%s] New ticket: %s (%s)',
			strtoupper( $priority ),
			get_the_title( $post_id ),
			$cat_label
		);

		$body  = "A new support ticket was submitted.\n\n";
		$body .= "Customer: {$name} <{$email}>\n";
		$body .= "Category: {$cat_label}\n";
		$body .= 'Priority: ' . strtoupper( $priority ) . "\n";
		if ( $order ) {
			$body .= "Order #: {$order}\n";
		}
		$body .= "\nMessage:\n" . get_post_field( 'post_content', $post_id );
		$body .= "\n\nView and reply: " . admin_url( 'post.php?post=' . $post_id . '&action=edit' );

		wp_mail( $this->admin_email(), $subject, $body );
	}

	/** Staff replies via the native comment box on the ticket -> notify customer. */
	public function maybe_notify_on_reply( $comment_id, $comment ) {
		if ( 'gp_ticket' !== get_post_type( $comment->comment_post_ID ) ) {
			return;
		}
		// Only fire for staff replies (comment author is a logged-in user), not
		// for the customer's own reply, which is written directly, not via wp_insert_comment.
		if ( ! $comment->user_id ) {
			return;
		}

		$post_id = $comment->comment_post_ID;
		update_post_meta( $post_id, '_gpst_status', 'waiting_on_customer' );

		$email = get_post_meta( $post_id, '_gpst_customer_email', true );
		$token = get_post_meta( $post_id, '_gpst_token', true );
		if ( ! $email ) {
			return;
		}

		$status_url = GPST_Frontend::instance()->get_status_url( $post_id, $token );

		$subject = 'Update on your support ticket: ' . get_the_title( $post_id );
		$body  = "We've replied to your support ticket.\n\n";
		$body .= $comment->comment_content . "\n\n";
		$body .= "View the full conversation and reply here:\n{$status_url}";

		wp_mail( $email, $subject, $body );
	}

	/** Admin manually changes status in the meta box (e.g. Resolved). */
	public function notify_customer_status_change( $post_id, $new_status ) {
		$email = get_post_meta( $post_id, '_gpst_customer_email', true );
		if ( ! $email ) {
			return;
		}
		$token      = get_post_meta( $post_id, '_gpst_token', true );
		$status_url = GPST_Frontend::instance()->get_status_url( $post_id, $token );
		$statuses   = GPST_CPT::statuses();
		$label      = isset( $statuses[ $new_status ] ) ? $statuses[ $new_status ] : $new_status;

		$subject = 'Your ticket status changed: ' . get_the_title( $post_id );
		$body  = "Your support ticket is now marked: {$label}\n\n";
		$body .= "View it here:\n{$status_url}";

		wp_mail( $email, $subject, $body );
	}

	/** Customer submits a reply from the front-end status page -> notify staff. */
	public function notify_admin_customer_reply( $post_id ) {
		$subject = 'Customer replied: ' . get_the_title( $post_id );
		$body  = "The customer replied to an open ticket.\n\n";
		$body .= 'View and reply: ' . admin_url( 'post.php?post=' . $post_id . '&action=edit' );
		wp_mail( $this->admin_email(), $subject, $body );
	}

	/** Confirmation sent to the customer the moment they submit a ticket. */
	public function notify_customer_ticket_received( $post_id ) {
		$email = get_post_meta( $post_id, '_gpst_customer_email', true );
		if ( ! $email ) {
			return;
		}
		$token      = get_post_meta( $post_id, '_gpst_token', true );
		$status_url = GPST_Frontend::instance()->get_status_url( $post_id, $token );

		$subject = 'We received your request: ' . get_the_title( $post_id );
		$body  = "Thanks, we received your ticket and will get back to you shortly.\n\n";
		$body .= "You can check its status or add details any time here:\n{$status_url}";

		wp_mail( $email, $subject, $body );
	}
}
