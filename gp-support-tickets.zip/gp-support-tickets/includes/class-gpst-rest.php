<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public REST API, namespace gp/v1, for the headless frontend at
 * genesispeptides.com to call. This is the actual integration surface,
 * the shortcode form in class-gpst-frontend.php is a fallback that only
 * works if someone visits wp.genesispeptides.com directly.
 *
 * Endpoints:
 *   POST /wp-json/gp/v1/tickets              submit a new ticket
 *   GET  /wp-json/gp/v1/tickets/{id}          get ticket + thread (requires ?token=)
 *   POST /wp-json/gp/v1/tickets/{id}/reply    customer adds a reply (requires token in body)
 */
class GPST_REST {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'rest_api_init', array( $this, 'add_cors_headers' ), 15 );
	}

	/**
	 * Only the real storefront origin(s) may call this API. Edit this list
	 * once the frontend's actual domain(s) are confirmed (production +
	 * any staging/preview URLs the dev team uses).
	 */
	private function allowed_origins() {
		return apply_filters(
			'gpst_allowed_origins',
			array(
				'https://genesispeptides.com',
				'https://www.genesispeptides.com',
			)
		);
	}

	public function add_cors_headers() {
		remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
		add_filter(
			'rest_pre_serve_request',
			function ( $value ) {
				$origin = get_http_origin();
				if ( $origin && in_array( $origin, $this->allowed_origins(), true ) ) {
					header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
					header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
					header( 'Access-Control-Allow-Headers: Content-Type' );
				}
				return $value;
			}
		);
	}

	public function register_routes() {
		register_rest_route(
			'gp/v1',
			'/tickets',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'submit_ticket' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'name'         => array( 'required' => true, 'type' => 'string' ),
					'email'        => array( 'required' => true, 'type' => 'string' ),
					'category'     => array( 'required' => true, 'type' => 'string' ),
					'order_number' => array( 'required' => false, 'type' => 'string' ),
					'message'      => array( 'required' => true, 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			'gp/v1',
			'/tickets/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_ticket' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'token' => array( 'required' => true, 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			'gp/v1',
			'/tickets/(?P<id>\d+)/reply',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reply_to_ticket' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'token'   => array( 'required' => true, 'type' => 'string' ),
					'message' => array( 'required' => true, 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			'gp/v1',
			'/categories',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_categories' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function submit_ticket( WP_REST_Request $request ) {
		$result = GPST_Ticket_Service::instance()->create_ticket(
			array(
				'name'         => $request->get_param( 'name' ),
				'email'        => $request->get_param( 'email' ),
				'category'     => $request->get_param( 'category' ),
				'order_number' => $request->get_param( 'order_number' ),
				'message'      => $request->get_param( 'message' ),
			)
		);

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( $result, 201 );
	}

	public function get_ticket( WP_REST_Request $request ) {
		$result = GPST_Ticket_Service::instance()->get_ticket_payload(
			(int) $request->get_param( 'id' ),
			$request->get_param( 'token' )
		);

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( $result, 200 );
	}

	public function reply_to_ticket( WP_REST_Request $request ) {
		$result = GPST_Ticket_Service::instance()->add_customer_reply(
			(int) $request->get_param( 'id' ),
			$request->get_param( 'token' ),
			$request->get_param( 'message' )
		);

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( array( 'success' => true ), 200 );
	}

	public function get_categories() {
		$out = array();
		foreach ( GPST_CPT::categories() as $key => $label ) {
			$out[] = array( 'value' => $key, 'label' => $label );
		}
		return new WP_REST_Response( $out, 200 );
	}

	private function error_response( WP_Error $error ) {
		$status = $error->get_error_data()['status'] ?? 400;
		return new WP_REST_Response(
			array(
				'error'   => $error->get_error_code(),
				'message' => $error->get_error_message(),
			),
			$status
		);
	}
}
