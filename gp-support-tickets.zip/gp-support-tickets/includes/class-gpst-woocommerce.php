<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pulls a read-only order snapshot into the ticket admin screen when
 * WooCommerce is active and an order number was provided. This plugin
 * never writes back to WooCommerce, it only reads, so there's no risk
 * of it interfering with Kentro-driven order/inventory sync.
 */
class GPST_WooCommerce {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function render_order_snapshot( $order_number ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return '';
		}

		$order = wc_get_order( $order_number );
		if ( ! $order ) {
			return '<p class="gpst-order-snapshot gpst-order-not-found">No matching WooCommerce order found for #' . esc_html( $order_number ) . '.</p>';
		}

		$html  = '<div class="gpst-order-snapshot">';
		$html .= '<h4>Order Snapshot</h4>';
		$html .= '<p><strong>Status:</strong> ' . esc_html( wc_get_order_status_name( $order->get_status() ) ) . '</p>';
		$html .= '<p><strong>Total:</strong> ' . wp_kses_post( $order->get_formatted_order_total() ) . '</p>';
		$html .= '<p><strong>Date:</strong> ' . esc_html( $order->get_date_created() ? $order->get_date_created()->date_i18n( 'M j, Y' ) : '-' ) . '</p>';
		$html .= '<p><a href="' . esc_url( admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' ) ) . '">View full order</a></p>';
		$html .= '</div>';

		return $html;
	}
}
