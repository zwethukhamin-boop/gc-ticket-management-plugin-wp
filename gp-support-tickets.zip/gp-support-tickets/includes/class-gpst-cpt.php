<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the "gp_ticket" post type and its meta boxes.
 * A ticket is just a post with structured meta on top, so it plays
 * nicely with the native WordPress comment thread, dashboard, and
 * capability system instead of inventing a parallel data model.
 */
class GPST_CPT {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Fixed category list. Edit this array to change the dropdown everywhere. */
	public static function categories() {
		return array(
			'order_status'   => 'Order Status / Tracking',
			'payment'        => 'Payment Issue',
			'stock_question' => 'Product / Stock Question',
			'coa_lab'        => 'Certificate of Analysis / Lab Test',
			'return_refund'  => 'Return or Refund',
			'account'        => 'Account Access',
			'other'          => 'Other',
		);
	}

	public static function statuses() {
		return array(
			'open'               => 'Open',
			'waiting_on_customer' => 'Waiting on Customer',
			'resolved'           => 'Resolved',
			'closed'             => 'Closed',
		);
	}

	public static function priorities() {
		return array(
			'urgent' => 'Urgent',
			'normal' => 'Normal',
		);
	}

	private function __construct() {
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_gp_ticket', array( $this, 'save_meta' ) );
		add_filter( 'comment_form_default_fields', array( $this, 'restrict_comment_form' ) );
	}

	public function register_post_type() {
		$labels = array(
			'name'               => 'Tickets',
			'singular_name'      => 'Ticket',
			'menu_name'          => 'Support Tickets',
			'add_new_item'       => 'Add Ticket',
			'edit_item'          => 'Edit Ticket',
			'new_item'           => 'New Ticket',
			'view_item'          => 'View Ticket',
			'search_items'       => 'Search Tickets',
			'not_found'          => 'No tickets found',
			'not_found_in_trash' => 'No tickets in trash',
		);

		register_post_type(
			'gp_ticket',
			array(
				'labels'              => $labels,
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'menu_icon'           => 'dashicons-tickets-alt',
				'supports'            => array( 'title', 'comments' ),
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'has_archive'         => false,
				'exclude_from_search' => true,
				'show_in_rest'        => false,
			)
		);
	}

	public function add_meta_boxes() {
		add_meta_box(
			'gpst_ticket_details',
			'Ticket Details',
			array( $this, 'render_meta_box' ),
			'gp_ticket',
			'side',
			'high'
		);
	}

	public function render_meta_box( $post ) {
		wp_nonce_field( 'gpst_save_ticket', 'gpst_ticket_nonce' );

		$category = get_post_meta( $post->ID, '_gpst_category', true );
		$priority = get_post_meta( $post->ID, '_gpst_priority', true );
		$status   = get_post_meta( $post->ID, '_gpst_status', true );
		$order    = get_post_meta( $post->ID, '_gpst_order_number', true );
		$email    = get_post_meta( $post->ID, '_gpst_customer_email', true );
		$name     = get_post_meta( $post->ID, '_gpst_customer_name', true );

		echo '<p><label><strong>Customer Name</strong></label><br />';
		echo '<input type="text" name="gpst_customer_name" value="' . esc_attr( $name ) . '" class="widefat" /></p>';

		echo '<p><label><strong>Customer Email</strong></label><br />';
		echo '<input type="email" name="gpst_customer_email" value="' . esc_attr( $email ) . '" class="widefat" /></p>';

		echo '<p><label><strong>Order Number</strong></label><br />';
		echo '<input type="text" name="gpst_order_number" value="' . esc_attr( $order ) . '" class="widefat" placeholder="e.g. 10432" /></p>';

		echo '<p><label><strong>Category</strong></label><br />';
		echo '<select name="gpst_category" class="widefat">';
		foreach ( self::categories() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $category, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></p>';

		echo '<p><label><strong>Priority</strong></label><br />';
		echo '<select name="gpst_priority" class="widefat">';
		foreach ( self::priorities() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $priority, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<span class="description">Auto-set on submission. Override here if needed.</span></p>';

		echo '<p><label><strong>Status</strong></label><br />';
		echo '<select name="gpst_status" class="widefat">';
		foreach ( self::statuses() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $status, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></p>';

		if ( $order && class_exists( 'WooCommerce' ) ) {
			echo GPST_WooCommerce::instance()->render_order_snapshot( $order );
		}
	}

	public function save_meta( $post_id ) {
		if ( ! isset( $_POST['gpst_ticket_nonce'] ) || ! wp_verify_nonce( $_POST['gpst_ticket_nonce'], 'gpst_save_ticket' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$fields = array(
			'gpst_customer_name'  => '_gpst_customer_name',
			'gpst_customer_email' => '_gpst_customer_email',
			'gpst_order_number'   => '_gpst_order_number',
			'gpst_category'       => '_gpst_category',
			'gpst_priority'       => '_gpst_priority',
			'gpst_status'         => '_gpst_status',
		);

		$old_status = get_post_meta( $post_id, '_gpst_status', true );

		foreach ( $fields as $input_key => $meta_key ) {
			if ( isset( $_POST[ $input_key ] ) ) {
				$value = 'gpst_customer_email' === $input_key
					? sanitize_email( wp_unslash( $_POST[ $input_key ] ) )
					: sanitize_text_field( wp_unslash( $_POST[ $input_key ] ) );
				update_post_meta( $post_id, $meta_key, $value );
			}
		}

		$new_status = get_post_meta( $post_id, '_gpst_status', true );

		// If an admin flips status to waiting-on-customer or resolved, notify the customer.
		if ( $old_status !== $new_status && in_array( $new_status, array( 'waiting_on_customer', 'resolved' ), true ) ) {
			GPST_Notifications::instance()->notify_customer_status_change( $post_id, $new_status );
		}
	}

	/**
	 * Keep the native comment form intact but we don't render it publicly ourselves
	 * (the front-end status page renders its own reply form). This just makes sure
	 * a stray theme call to comment_form() on a gp_ticket doesn't leak admin fields.
	 */
	public function restrict_comment_form( $fields ) {
		return $fields;
	}
}
