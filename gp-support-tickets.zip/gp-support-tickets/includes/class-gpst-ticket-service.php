<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single source of truth for creating tickets, reading a ticket's thread,
 * and adding a customer reply. Both the on-site shortcode form and the
 * REST API (used by the Next.js frontend) call into this, so there is
 * exactly one place that enforces validation and token checks.
 */
class GPST_Ticket_Service {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/**
	 * @param array $data { name, email, category, order_number, message }
	 * @return array|WP_Error { ticket_id, token, priority, status }
	 */
	public function create_ticket( $data ) {
		$name     = sanitize_text_field( $data['name'] ?? '' );
		$email    = sanitize_email( $data['email'] ?? '' );
		$category = sanitize_text_field( $data['category'] ?? '' );
		$order    = sanitize_text_field( $data['order_number'] ?? '' );
		$message  = sanitize_textarea_field( $data['message'] ?? '' );

		if ( ! $name || ! is_email( $email ) || ! $message ) {
			return new WP_Error( 'gpst_invalid', 'Name, a valid email, and a message are required.', array( 'status' => 400 ) );
		}

		$categories = GPST_CPT::categories();
		if ( ! isset( $categories[ $category ] ) ) {
			return new WP_Error( 'gpst_invalid_category', 'Category must be one of: ' . implode( ', ', array_keys( $categories ) ), array( 'status' => 400 ) );
		}

		$title = sprintf( '%s - %s', $name, current_time( 'Y-m-d H:i' ) );

		$post_id = wp_insert_post(
			array(
				'post_type'      => 'gp_ticket',
				'post_title'     => wp_strip_all_tags( $title ),
				'post_content'   => $message,
				'post_status'    => 'publish',
				'comment_status' => 'open',
			)
		);

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return new WP_Error( 'gpst_create_failed', 'Could not create the ticket.', array( 'status' => 500 ) );
		}

		$priority = GPST_Routing::instance()->calculate_priority( $category, $message, false );
		$token    = bin2hex( random_bytes( 16 ) );

		update_post_meta( $post_id, '_gpst_customer_name', $name );
		update_post_meta( $post_id, '_gpst_customer_email', $email );
		update_post_meta( $post_id, '_gpst_category', $category );
		update_post_meta( $post_id, '_gpst_order_number', $order );
		update_post_meta( $post_id, '_gpst_priority', $priority );
		update_post_meta( $post_id, '_gpst_status', 'open' );
		update_post_meta( $post_id, '_gpst_token', $token );

		GPST_Notifications::instance()->notify_admin_new_ticket( $post_id );
		GPST_Notifications::instance()->notify_customer_ticket_received( $post_id );

		return array(
			'ticket_id' => $post_id,
			'token'     => $token,
			'priority'  => $priority,
			'status'    => 'open',
		);
	}

	/**
	 * @return bool True if the token matches the ticket, false otherwise.
	 */
	public function token_matches( $ticket_id, $token ) {
		if ( ! $ticket_id || ! $token ) {
			return false;
		}
		$stored = get_post_meta( $ticket_id, '_gpst_token', true );
		return $stored && hash_equals( $stored, (string) $token );
	}

	/**
	 * @return array|WP_Error Full ticket payload: details plus the thread.
	 */
	public function get_ticket_payload( $ticket_id, $token ) {
		if ( ! get_post( $ticket_id ) || 'gp_ticket' !== get_post_type( $ticket_id ) ) {
			return new WP_Error( 'gpst_not_found', 'Ticket not found.', array( 'status' => 404 ) );
		}
		if ( ! $this->token_matches( $ticket_id, $token ) ) {
			return new WP_Error( 'gpst_forbidden', 'Invalid ticket token.', array( 'status' => 403 ) );
		}

		$statuses   = GPST_CPT::statuses();
		$categories = GPST_CPT::categories();
		$status_key = get_post_meta( $ticket_id, '_gpst_status', true );
		$category   = get_post_meta( $ticket_id, '_gpst_category', true );

		$thread   = array();
		$thread[] = array(
			'author'  => 'customer',
			'message' => get_post_field( 'post_content', $ticket_id ),
			'date'    => get_post_field( 'post_date', $ticket_id ),
		);

		$comments = get_comments( array( 'post_id' => $ticket_id, 'order' => 'ASC' ) );
		foreach ( $comments as $comment ) {
			$thread[] = array(
				'author'  => ! empty( $comment->user_id ) ? 'staff' : 'customer',
				'message' => $comment->comment_content,
				'date'    => $comment->comment_date,
			);
		}

		return array(
			'ticket_id'     => (int) $ticket_id,
			'title'         => get_the_title( $ticket_id ),
			'status'        => $status_key,
			'status_label'  => $statuses[ $status_key ] ?? $status_key,
			'category'      => $category,
			'category_label' => $categories[ $category ] ?? $category,
			'priority'      => get_post_meta( $ticket_id, '_gpst_priority', true ),
			'order_number'  => get_post_meta( $ticket_id, '_gpst_order_number', true ),
			'is_closed'     => in_array( $status_key, array( 'resolved', 'closed' ), true ),
			'thread'        => $thread,
		);
	}

	/**
	 * @return bool|WP_Error
	 */
	public function add_customer_reply( $ticket_id, $token, $message ) {
		if ( ! $this->token_matches( $ticket_id, $token ) ) {
			return new WP_Error( 'gpst_forbidden', 'Invalid ticket token.', array( 'status' => 403 ) );
		}

		$message = sanitize_textarea_field( $message );
		if ( ! $message ) {
			return new WP_Error( 'gpst_invalid', 'Message is required.', array( 'status' => 400 ) );
		}

		$status_key = get_post_meta( $ticket_id, '_gpst_status', true );
		if ( in_array( $status_key, array( 'resolved', 'closed' ), true ) ) {
			return new WP_Error( 'gpst_closed', 'This ticket is closed. Submit a new ticket for further help.', array( 'status' => 409 ) );
		}

		$name  = get_post_meta( $ticket_id, '_gpst_customer_name', true );
		$email = get_post_meta( $ticket_id, '_gpst_customer_email', true );

		wp_insert_comment(
			array(
				'comment_post_ID'      => $ticket_id,
				'comment_author'       => $name,
				'comment_author_email' => $email,
				'comment_content'      => $message,
				'user_id'              => 0,
				'comment_approved'     => 1,
			)
		);

		// A customer following up on an already-open ticket is always urgent,
		// per the routing rule: repeat contact means the first answer didn't land.
		update_post_meta( $ticket_id, '_gpst_status', 'open' );
		update_post_meta( $ticket_id, '_gpst_priority', 'urgent' );

		GPST_Notifications::instance()->notify_admin_customer_reply( $ticket_id );

		return true;
	}
}
