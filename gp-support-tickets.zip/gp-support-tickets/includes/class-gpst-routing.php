<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decides priority automatically. The customer never picks urgency,
 * the system infers it from category and message content, so nobody
 * can game the queue by marking everything "urgent."
 */
class GPST_Routing {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/** Categories that are automatically high impact (money or an unfulfilled order at stake). */
	private $urgent_categories = array( 'payment', 'order_status', 'coa_lab' );

	/** Keywords that bump priority to urgent regardless of category. */
	private $urgent_keywords = array(
		'certificate of analysis',
		'coa',
		'lab test',
		'lab report',
		'chargeback',
		'dispute',
		'never arrived',
		'not delivered',
		'wrong item',
		'damaged',
		'refund',
		'unauthorized',
	);

	/**
	 * @param string $category    One of GPST_CPT::categories() keys.
	 * @param string $message     Raw ticket message body.
	 * @param bool   $is_followup Whether this is a repeat contact on an unresolved ticket.
	 * @return string 'urgent' or 'normal'
	 */
	public function calculate_priority( $category, $message, $is_followup = false ) {
		if ( $is_followup ) {
			return 'urgent';
		}

		if ( in_array( $category, $this->urgent_categories, true ) ) {
			return 'urgent';
		}

		$message_lower = strtolower( $message );
		foreach ( $this->urgent_keywords as $keyword ) {
			if ( false !== strpos( $message_lower, $keyword ) ) {
				return 'urgent';
			}
		}

		return 'normal';
	}
}
