<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Two shortcodes:
 *   [gp_ticket_form]   - the submission form customers fill out.
 *   [gp_ticket_status] - the page a customer lands on (via emailed link) to see
 *                         the thread and reply. No account/login required, access
 *                         is controlled by a random token in the URL.
 *
 * Put [gp_ticket_form] on your "Contact / Get Help" page and [gp_ticket_status]
 * on its own page, e.g. /ticket-status/. The plugin finds that page automatically
 * for the links it emails out.
 */
class GPST_Frontend {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'gp_ticket_form', array( $this, 'render_form' ) );
		add_shortcode( 'gp_ticket_status', array( $this, 'render_status' ) );
		add_action( 'init', array( $this, 'handle_form_submission' ) );
		add_action( 'init', array( $this, 'handle_customer_reply' ) );
	}

	/** ---------- Submission form ---------- */

	public function render_form() {
		ob_start();

		if ( isset( $_GET['gpst_submitted'] ) ) {
			echo '<div class="gpst-notice gpst-notice-success">Thanks, we received your ticket. Check your email for a link to track it.</div>';
			return ob_get_clean();
		}

		$categories = GPST_CPT::categories();
		?>
		<form class="gpst-form" method="post">
			<?php wp_nonce_field( 'gpst_submit_ticket', 'gpst_form_nonce' ); ?>
			<input type="hidden" name="gpst_action" value="submit_ticket" />

			<p class="gpst-field">
				<label for="gpst_name">Name</label>
				<input type="text" id="gpst_name" name="gpst_name" required />
			</p>

			<p class="gpst-field">
				<label for="gpst_email">Email</label>
				<input type="email" id="gpst_email" name="gpst_email" required />
			</p>

			<p class="gpst-field">
				<label for="gpst_category">What's this about?</label>
				<select id="gpst_category" name="gpst_category" required>
					<option value="">Select one</option>
					<?php foreach ( $categories as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>

			<p class="gpst-field">
				<label for="gpst_order_number">Order number <span class="gpst-optional">(if applicable)</span></label>
				<input type="text" id="gpst_order_number" name="gpst_order_number" />
			</p>

			<p class="gpst-field">
				<label for="gpst_message">Tell us what's going on</label>
				<textarea id="gpst_message" name="gpst_message" rows="5" required></textarea>
			</p>

			<p class="gpst-field">
				<button type="submit">Submit</button>
			</p>
		</form>
		<?php
		return ob_get_clean();
	}

	public function handle_form_submission() {
		if ( ! isset( $_POST['gpst_action'] ) || 'submit_ticket' !== $_POST['gpst_action'] ) {
			return;
		}
		if ( ! isset( $_POST['gpst_form_nonce'] ) || ! wp_verify_nonce( $_POST['gpst_form_nonce'], 'gpst_submit_ticket' ) ) {
			wp_die( 'Security check failed. Please go back and try again.' );
		}

		$result = GPST_Ticket_Service::instance()->create_ticket(
			array(
				'name'         => wp_unslash( $_POST['gpst_name'] ?? '' ),
				'email'        => wp_unslash( $_POST['gpst_email'] ?? '' ),
				'category'     => wp_unslash( $_POST['gpst_category'] ?? '' ),
				'order_number' => wp_unslash( $_POST['gpst_order_number'] ?? '' ),
				'message'      => wp_unslash( $_POST['gpst_message'] ?? '' ),
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ) . ' Please go back and try again.' );
		}

		wp_safe_redirect( add_query_arg( 'gpst_submitted', '1', wp_get_referer() ?: home_url() ) );
		exit;
	}

	/** ---------- Status / thread page ---------- */

	public function render_status() {
		$ticket_id = isset( $_GET['gpst_ticket'] ) ? absint( $_GET['gpst_ticket'] ) : 0;
		$token     = isset( $_GET['gpst_token'] ) ? sanitize_text_field( wp_unslash( $_GET['gpst_token'] ) ) : '';

		$payload = $ticket_id && $token ? GPST_Ticket_Service::instance()->get_ticket_payload( $ticket_id, $token ) : null;

		if ( ! $payload || is_wp_error( $payload ) ) {
			return '<div class="gpst-notice">Enter your ticket link from your confirmation email to view its status.</div>';
		}

		ob_start();

		echo '<div class="gpst-status">';
		echo '<h3>' . esc_html( $payload['title'] ) . '</h3>';
		echo '<p class="gpst-status-badge gpst-status-' . esc_attr( $payload['status'] ) . '">Status: ' . esc_html( $payload['status_label'] ) . '</p>';

		echo '<div class="gpst-thread">';
		foreach ( $payload['thread'] as $entry ) {
			$is_staff = 'staff' === $entry['author'];
			$class    = $is_staff ? 'gpst-message-staff' : 'gpst-message-customer';
			$who      = $is_staff ? 'Genesis Peptides Support' : 'You';
			echo '<div class="gpst-message ' . esc_attr( $class ) . '"><strong>' . esc_html( $who ) . '</strong><p>' . nl2br( esc_html( $entry['message'] ) ) . '</p></div>';
		}
		echo '</div>';

		if ( ! $payload['is_closed'] ) {
			?>
			<form class="gpst-reply-form" method="post">
				<?php wp_nonce_field( 'gpst_customer_reply', 'gpst_reply_nonce' ); ?>
				<input type="hidden" name="gpst_action" value="customer_reply" />
				<input type="hidden" name="gpst_ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>" />
				<input type="hidden" name="gpst_token" value="<?php echo esc_attr( $token ); ?>" />
				<textarea name="gpst_reply_message" rows="4" placeholder="Add more details or reply..." required></textarea>
				<button type="submit">Send</button>
			</form>
			<?php
		} else {
			echo '<p class="gpst-notice">This ticket is closed. Submit a new ticket if you need further help.</p>';
		}

		echo '</div>';

		return ob_get_clean();
	}

	public function handle_customer_reply() {
		if ( ! isset( $_POST['gpst_action'] ) || 'customer_reply' !== $_POST['gpst_action'] ) {
			return;
		}
		if ( ! isset( $_POST['gpst_reply_nonce'] ) || ! wp_verify_nonce( $_POST['gpst_reply_nonce'], 'gpst_customer_reply' ) ) {
			wp_die( 'Security check failed. Please go back and try again.' );
		}

		$ticket_id = absint( $_POST['gpst_ticket_id'] ?? 0 );
		$token     = sanitize_text_field( wp_unslash( $_POST['gpst_token'] ?? '' ) );
		$message   = wp_unslash( $_POST['gpst_reply_message'] ?? '' );

		$result = GPST_Ticket_Service::instance()->add_customer_reply( $ticket_id, $token, $message );

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ) );
		}

		wp_safe_redirect( wp_get_referer() ?: home_url() );
		exit;
	}

	/** ---------- Helpers ---------- */

	/**
	 * Finds the page containing [gp_ticket_status] and builds a link to it.
	 * Falls back to the homepage with a note if no such page exists yet,
	 * so setup mistakes are visible in the admin's own inbox, not silent.
	 */
	public function get_status_url( $ticket_id, $token ) {
		$cached = get_transient( 'gpst_status_page_id' );
		if ( false === $cached ) {
			$page = get_posts(
				array(
					'post_type'   => 'page',
					's'           => '[gp_ticket_status]',
					'numberposts' => 1,
				)
			);
			$cached = $page ? $page[0]->ID : 0;
			set_transient( 'gpst_status_page_id', $cached, HOUR_IN_SECONDS );
		}

		$base = $cached ? get_permalink( $cached ) : home_url( '/' );

		return add_query_arg(
			array(
				'gpst_ticket' => $ticket_id,
				'gpst_token'  => $token,
			),
			$base
		);
	}
}
