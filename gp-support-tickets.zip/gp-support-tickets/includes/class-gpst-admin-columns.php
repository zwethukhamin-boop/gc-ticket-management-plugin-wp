<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns the default "Posts" list table into a usable ticket queue:
 * priority and status up front, filterable, sorted urgent-first.
 */
class GPST_Admin_Columns {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'manage_gp_ticket_posts_columns', array( $this, 'columns' ) );
		add_action( 'manage_gp_ticket_posts_custom_column', array( $this, 'render_column' ), 10, 2 );
		add_filter( 'manage_edit-gp_ticket_sortable_columns', array( $this, 'sortable_columns' ) );
		add_action( 'pre_get_posts', array( $this, 'default_sort_and_filter' ) );
		add_action( 'restrict_manage_posts', array( $this, 'status_filter_dropdown' ) );
	}

	public function columns( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['gpst_priority'] = 'Priority';
				$new['gpst_status']   = 'Status';
				$new['gpst_category'] = 'Category';
				$new['gpst_order']    = 'Order #';
				$new['gpst_customer'] = 'Customer';
			}
		}
		unset( $new['comments'] ); // We use the count elsewhere; keep the list lean.
		return $new;
	}

	public function render_column( $column, $post_id ) {
		switch ( $column ) {
			case 'gpst_priority':
				$priority = get_post_meta( $post_id, '_gpst_priority', true );
				$label    = 'urgent' === $priority ? 'Urgent' : 'Normal';
				echo '<span class="gpst-pill gpst-pill-' . esc_attr( $priority ) . '">' . esc_html( $label ) . '</span>';
				break;

			case 'gpst_status':
				$status    = get_post_meta( $post_id, '_gpst_status', true );
				$statuses  = GPST_CPT::statuses();
				$label     = isset( $statuses[ $status ] ) ? $statuses[ $status ] : $status;
				echo '<span class="gpst-pill gpst-pill-status-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
				break;

			case 'gpst_category':
				$category   = get_post_meta( $post_id, '_gpst_category', true );
				$categories = GPST_CPT::categories();
				echo esc_html( isset( $categories[ $category ] ) ? $categories[ $category ] : $category );
				break;

			case 'gpst_order':
				echo esc_html( get_post_meta( $post_id, '_gpst_order_number', true ) ?: '-' );
				break;

			case 'gpst_customer':
				$name  = get_post_meta( $post_id, '_gpst_customer_name', true );
				$email = get_post_meta( $post_id, '_gpst_customer_email', true );
				echo esc_html( $name ) . '<br /><small>' . esc_html( $email ) . '</small>';
				break;
		}
	}

	public function sortable_columns( $columns ) {
		$columns['gpst_priority'] = 'gpst_priority';
		$columns['gpst_status']   = 'gpst_status';
		return $columns;
	}

	/**
	 * Default view: open/urgent tickets first, so the queue itself tells you
	 * what to work on without needing to click a filter.
	 */
	public function default_sort_and_filter( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'gp_ticket' !== $query->get( 'post_type' ) ) {
			return;
		}

		if ( 'gpst_priority' === $query->get( 'orderby' ) ) {
			$query->set( 'meta_key', '_gpst_priority' );
			$query->set( 'orderby', 'meta_value' );
		} elseif ( ! $query->get( 'orderby' ) ) {
			// No explicit sort chosen: default to newest first, urgent visually
			// stands out via the pill styling rather than forcing a meta sort
			// that would hide recency.
			$query->set( 'orderby', 'date' );
			$query->set( 'order', 'DESC' );
		}

		if ( ! empty( $_GET['gpst_status_filter'] ) ) {
			$query->set(
				'meta_query',
				array(
					array(
						'key'   => '_gpst_status',
						'value' => sanitize_text_field( wp_unslash( $_GET['gpst_status_filter'] ) ),
					),
				)
			);
		}
	}

	public function status_filter_dropdown() {
		global $typenow;
		if ( 'gp_ticket' !== $typenow ) {
			return;
		}
		$current = isset( $_GET['gpst_status_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['gpst_status_filter'] ) ) : '';
		echo '<select name="gpst_status_filter">';
		echo '<option value="">All statuses</option>';
		foreach ( GPST_CPT::statuses() as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $current, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	}
}
